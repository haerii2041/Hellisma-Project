/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package admin;
import santri.riwayat_setoran;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import koneksi.Koneksi;
import java.sql.Connection;
import admin.akun_santri;
import santri.halaman_santri;
import org.mindrot.jbcrypt.BCrypt;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import login.form_login;


/**
 *
 * @author ONESIA
 */
public class data_setoran extends javax.swing.JFrame {

    /**
     * Creates new form data_setoran
     */
    private String usernameUstadz;
    
    public class ComboItem {
        private int id;
        private String name;

        public ComboItem(int id, String name) {
            this.id = id;
            this.name = name;
        }

        public int getId() { return id; }
        public String toString() { return name; }
    }
    public data_setoran(String usernameUstadz) {
        initComponents();
        this.usernameUstadz = usernameUstadz;
        tampilkanNamaUstadz();      // isi label berdasarkan username
        isiComboSantri();
        tampilkanTabelSetoran();
    }
    
    
    
    private void tampilkanNamaUstadz() {
        try {
            Connection con = koneksi.Koneksi.getConnection();
            String sql = "SELECT nama_ustadz FROM ustadz WHERE username = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, usernameUstadz);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                lblUstadz.setText(rs.getString("nama_ustadz"));
            } else {
                lblUstadz.setText("Tidak ditemukan");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error ambil ustadz: " + e.getMessage());
        }
    }
    
    private void isiComboSantri() {
        try {
            Connection con = koneksi.Koneksi.getConnection();
            String sql = "SELECT id_santri, nama_santri FROM santri";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                cmbSantri.addItem(new ComboItem(rs.getInt("id_santri"), rs.getString("nama_santri")));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal mengisi combo santri: " + e.getMessage());
        }
    }
    
    // Menampilkan data setoran ke tabel
    private void tampilkanTabelSetoran() {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("No");
        model.addColumn("Santri");
        model.addColumn("Tanggal");
        model.addColumn("Surah");
        model.addColumn("Ayat");
        model.addColumn("Keterangan");

        try {
            Connection con = koneksi.Koneksi.getConnection();
            String sql = "SELECT s.nama_santri, st.tanggal_setoran, st.dari_surah, st.dari_ayat, st.sampai_surah, st.sampai_ayat, st.keterangan FROM setoran st JOIN santri s ON st.id_santri = s.id_santri WHERE st.id_ustadz = (SELECT id_ustadz FROM ustadz WHERE username = ?) ORDER BY st.tanggal_setoran DESC";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, usernameUstadz);
            ResultSet rs = pst.executeQuery();

            int no = 1;
            while (rs.next()) {
                String surah = rs.getString("dari_surah") + " - " + rs.getString("sampai_surah");
                String ayat = rs.getInt("dari_ayat") + " - " + rs.getInt("sampai_ayat");
                model.addRow(new Object[]{no++, rs.getString("nama_santri"), rs.getString("tanggal_setoran"), surah, ayat, rs.getString("keterangan")});
            }
            tableSetoran.setModel(model);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal menampilkan data: " + e.getMessage());
        }
    }
    
    private void tampilkanDataSetoran() {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("No");
        model.addColumn("Santri");
        model.addColumn("Tanggal");
        model.addColumn("Surah Dari");
        model.addColumn("Ayat Dari");
        model.addColumn("Surah Sampai");
        model.addColumn("Ayat Sampai");
        model.addColumn("Keterangan");

        try {
            Connection con = koneksi.Koneksi.getConnection();
            String sql = "SELECT s.nama_santri, st.* FROM setoran st JOIN santri s ON s.id_santri = st.id_santri WHERE st.id_ustadz = (SELECT id_ustadz FROM ustadz WHERE username = ?) ORDER BY st.tanggal_setoran DESC";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, usernameUstadz);
            ResultSet rs = pst.executeQuery();

            int no = 1;
            while (rs.next()) {
                model.addRow(new Object[] {
                    no++,
                    rs.getString("nama_santri"),
                    rs.getString("tanggal_setoran"),
                    rs.getString("dari_surah"),
                    rs.getInt("dari_ayat"),
                    rs.getString("sampai_surah"),
                    rs.getInt("sampai_ayat"),
                    rs.getString("keterangan")
                });
            }

            tableSetoran.setModel(model);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal tampilkan data: " + e.getMessage());
        }
    }
    
    private void resetForm() {
        cmbSantri.setSelectedIndex(0);
        txtTglSetoran.setText("");
        txtDariSurah.setText("");
        txtDariAyat.setText("");
        txtSampaiSurah.setText("");
        txtSampaiAyat.setText("");
        txtKeterangan.setText("");
    }
    private void tableSetoranMouseClicked(java.awt.event.MouseEvent evt) {
        int row = tableSetoran.getSelectedRow();
        if (row != -1) {
        String namaSantri = tableSetoran.getValueAt(row, 1).toString();
        for (int i = 0; i < cmbSantri.getItemCount(); i++) {
        if (cmbSantri.getItemAt(i).toString().equals(namaSantri)) {
        cmbSantri.setSelectedIndex(i);
        break;
        }
        }

            txtTglSetoran.setText(tableSetoran.getValueAt(row, 2).toString());
            txtDariSurah.setText(tableSetoran.getValueAt(row, 3).toString());
            txtDariAyat.setText(tableSetoran.getValueAt(row, 4).toString());
            txtSampaiSurah.setText(tableSetoran.getValueAt(row, 5).toString());
            txtSampaiAyat.setText(tableSetoran.getValueAt(row, 6).toString());
            txtKeterangan.setText(tableSetoran.getValueAt(row, 7).toString());
    }
}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton4 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableSetoran = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        cmbSantri = new javax.swing.JComboBox();
        txtTglSetoran = new javax.swing.JTextField();
        txtDariSurah = new javax.swing.JTextField();
        txtDariAyat = new javax.swing.JTextField();
        txtSampaiSurah = new javax.swing.JTextField();
        txtSampaiAyat = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtKeterangan = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        btnRiwayat = new javax.swing.JButton();
        lblUstadz = new javax.swing.JLabel();
        btnLogout = new javax.swing.JButton();

        jButton4.setText("Reset Form");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));

        tableSetoran.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "No", "Santri", "Ustadz", "Tanggal Setoran", "Dari Surah", "Dari Ayat", "Sampai Surah", "Sampai Ayat", "Keterangan"
            }
        ));
        tableSetoran.setName("tableSetoran"); // NOI18N
        jScrollPane1.setViewportView(tableSetoran);

        jLabel1.setText("Santri");

        jLabel2.setText("Ustadz");

        jLabel3.setText("Tanggal Setoran");

        jLabel4.setText("Dari Surah");

        jLabel5.setText("Dari Ayat");

        jLabel6.setText("Sampai Surah");

        jLabel7.setText("Sampai Ayat");

        jLabel8.setText("Keterangan");

        cmbSantri.setName("cmbSantri"); // NOI18N

        txtTglSetoran.setName("txtTglSetoran"); // NOI18N

        txtDariSurah.setName("txtDariSurah"); // NOI18N

        txtDariAyat.setName("txtDariAyat"); // NOI18N
        txtDariAyat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDariAyatActionPerformed(evt);
            }
        });

        txtSampaiSurah.setName("txtSampaiSurah"); // NOI18N
        txtSampaiSurah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSampaiSurahActionPerformed(evt);
            }
        });

        txtSampaiAyat.setName("txtSampaiAyat"); // NOI18N
        txtSampaiAyat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSampaiAyatActionPerformed(evt);
            }
        });

        txtKeterangan.setColumns(20);
        txtKeterangan.setRows(5);
        txtKeterangan.setName("txtKeterangan"); // NOI18N
        jScrollPane2.setViewportView(txtKeterangan);

        jButton1.setText("Tambah");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Edit");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Hapus");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel9.setText("Data Setoran");

        btnRiwayat.setText("Riwayat Setoran");
        btnRiwayat.setName("btnRiwayat"); // NOI18N
        btnRiwayat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRiwayatActionPerformed(evt);
            }
        });

        lblUstadz.setText("Nama Ustadz");
        lblUstadz.setName("lblUstadz"); // NOI18N

        btnLogout.setText("Logout");
        btnLogout.setName("btnLogout"); // NOI18N
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(btnLogout)
                        .addGap(117, 117, 117)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8)
                            .addComponent(jLabel1)
                            .addComponent(btnRiwayat))
                        .addGap(52, 52, 52)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cmbSantri, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtSampaiAyat)
                            .addComponent(txtSampaiSurah)
                            .addComponent(txtDariAyat)
                            .addComponent(txtDariSurah)
                            .addComponent(txtTglSetoran)
                            .addComponent(jScrollPane2)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jButton1)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton2)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton3))
                                    .addComponent(lblUstadz))
                                .addGap(0, 343, Short.MAX_VALUE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(454, 454, 454)
                        .addComponent(jLabel9)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 153, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 679, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(164, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel9)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(cmbSantri, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(lblUstadz))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(txtTglSetoran, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(txtDariSurah, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(txtDariAyat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtSampaiSurah, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtSampaiAyat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3)
                    .addComponent(btnRiwayat)
                    .addComponent(btnLogout))
                .addContainerGap(29, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(56, 56, 56))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtDariAyatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDariAyatActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDariAyatActionPerformed

    private void txtSampaiSurahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSampaiSurahActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSampaiSurahActionPerformed

    private void txtSampaiAyatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSampaiAyatActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSampaiAyatActionPerformed

    private void btnRiwayatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRiwayatActionPerformed
        // TODO add your handling code here:
        riwayat_setoran riwayat = new riwayat_setoran(this.usernameUstadz);
        riwayat.setVisible(true);
        this.dispose(); // menutup halaman saat ini (data_setoran)
    }//GEN-LAST:event_btnRiwayatActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        try {
            ComboItem santriItem = (ComboItem) cmbSantri.getSelectedItem();
            int idSantri = santriItem.getId();

            // Ambil ID Ustadz dari username login
            int idUstadz = -1;
            Connection con = koneksi.Koneksi.getConnection();
            String sqlUstadz = "SELECT id_ustadz FROM ustadz WHERE username = ?";
            PreparedStatement pstUstadz = con.prepareStatement(sqlUstadz);
            pstUstadz.setString(1, usernameUstadz);
            ResultSet rsUstadz = pstUstadz.executeQuery();
            if (rsUstadz.next()) {
                idUstadz = rsUstadz.getInt("id_ustadz");
            } else {
                JOptionPane.showMessageDialog(this, "ID Ustadz tidak ditemukan.");
                return;
            }

            String sql = "INSERT INTO setoran (id_santri, id_ustadz, tanggal_setoran, dari_surah, dari_ayat, sampai_surah, sampai_ayat, keterangan) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, idSantri);
            pst.setInt(2, idUstadz);
            pst.setString(3, txtTglSetoran.getText());
            pst.setString(4, txtDariSurah.getText());
            pst.setInt(5, Integer.parseInt(txtDariAyat.getText()));
            pst.setString(6, txtSampaiSurah.getText());
            pst.setInt(7, Integer.parseInt(txtSampaiAyat.getText()));
            pst.setString(8, txtKeterangan.getText());
            pst.executeUpdate();

            JOptionPane.showMessageDialog(this, "Data setoran berhasil disimpan.");
            tampilkanTabelSetoran();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal menyimpan data: " + e.getMessage());
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        cmbSantri.setSelectedIndex(0);
        txtTglSetoran.setText("");
        txtDariSurah.setText("");
        txtDariAyat.setText("");
        txtSampaiSurah.setText("");
        txtSampaiAyat.setText("");
        txtKeterangan.setText("");
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        int selectedRow = tableSetoran.getSelectedRow();
        if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Pilih data yang akan diedit.");
        return;
        }

        try {
            ComboItem santriItem = (ComboItem) cmbSantri.getSelectedItem();
            int idSantri = santriItem.getId();

            // Ambil ID setoran dari baris terseleksi (opsional: simpan ID tersembunyi jika diperlukan)
            String tanggalSetoran = tableSetoran.getValueAt(selectedRow, 2).toString(); // gunakan kombinasi unik jika tidak ada id

            Connection con = koneksi.Koneksi.getConnection();
            String sql = "UPDATE setoran SET dari_surah=?, dari_ayat=?, sampai_surah=?, sampai_ayat=?, keterangan=? " +
                         "WHERE tanggal_setoran=? AND id_santri=? AND id_ustadz=(SELECT id_ustadz FROM ustadz WHERE username=?)";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, txtDariSurah.getText());
            pst.setInt(2, Integer.parseInt(txtDariAyat.getText()));
            pst.setString(3, txtSampaiSurah.getText());
            pst.setInt(4, Integer.parseInt(txtSampaiAyat.getText()));
            pst.setString(5, txtKeterangan.getText());
            pst.setString(6, tanggalSetoran);
            pst.setInt(7, idSantri);
            pst.setString(8, usernameUstadz);
            pst.executeUpdate();

            JOptionPane.showMessageDialog(this, "Data berhasil diperbarui.");
            tampilkanDataSetoran();
            resetForm();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal mengedit data: " + e.getMessage());
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        int selectedRow = tableSetoran.getSelectedRow();
        if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Pilih data yang akan dihapus.");
        return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Yakin ingin menghapus data ini?", "Konfirmasi", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        try {
            ComboItem santriItem = (ComboItem) cmbSantri.getSelectedItem();
            int idSantri = santriItem.getId();
            String tanggalSetoran = tableSetoran.getValueAt(selectedRow, 2).toString();

            Connection con = koneksi.Koneksi.getConnection();
            String sql = "DELETE FROM setoran WHERE tanggal_setoran=? AND id_santri=? AND id_ustadz=(SELECT id_ustadz FROM ustadz WHERE username=?)";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, tanggalSetoran);
            pst.setInt(2, idSantri);
            pst.setString(3, usernameUstadz);
            pst.executeUpdate();

            JOptionPane.showMessageDialog(this, "Data berhasil dihapus.");
            tampilkanDataSetoran();
            resetForm();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal menghapus data: " + e.getMessage());
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoutActionPerformed
        // TODO add your handling code here:
        int konfirmasi = JOptionPane.showConfirmDialog(this, "Yakin ingin logout?", "Logout", JOptionPane.YES_NO_OPTION);
        if (konfirmasi == JOptionPane.YES_OPTION) {
        new form_login().setVisible(true);
        this.dispose(); // Tutup form data_setoran
    }
    }//GEN-LAST:event_btnLogoutActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(data_setoran.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(data_setoran.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(data_setoran.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(data_setoran.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new data_setoran("ustadz_username_testing").setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnLogout;
    private javax.swing.JButton btnRiwayat;
    private javax.swing.JComboBox cmbSantri;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblUstadz;
    private javax.swing.JTable tableSetoran;
    private javax.swing.JTextField txtDariAyat;
    private javax.swing.JTextField txtDariSurah;
    private javax.swing.JTextArea txtKeterangan;
    private javax.swing.JTextField txtSampaiAyat;
    private javax.swing.JTextField txtSampaiSurah;
    private javax.swing.JTextField txtTglSetoran;
    // End of variables declaration//GEN-END:variables
}
